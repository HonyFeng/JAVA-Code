package JMailForPython;

import java.net.InetAddress;
import java.util.Date;

import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * 基本信息
 * @author gjt
 *
 */
public class Main {
	/**
	 * 设置qq邮箱接收服务器,其他邮箱同理，smtp.xx.com
	 */
	public static String SMTPHost = "smtp.qq.com";
	/**
	 * 设置接收人
	 */
	public static String recive = "xxxx@qq.com";
	/**
	 * 创建一封只包含文本的简单邮件
	 * @param session     和服务器交互
	 * @param sendMail    发送人
	 * @param receiveMail 接收人
	 * @param ip          发送的内容
	 * @return
	 * @throws Exception
	 * 2018年2月8日上午9:58:52
	 * name:官江涛
	 */
	public static MimeMessage createMimeMessage(Session session, String sendMail, String receiveMail,String message) throws Exception{
		
		//创建一封邮件
		MimeMessage me = new MimeMessage(session);
		//设置发件人
		me.setFrom(new InternetAddress(sendMail,"测试","utf-8"));
		/**
		 * To: 收件人（可以增加多个收件人、抄送、密送）
		 * setRecipient（Message.RecipientType type, Address address），用于设置邮件的接收者。有两个参数，第
		 * 一个参数是接收者的类型，第二个参数是接收者。接收者类型可以是Message.RecipientType.TO，Message.RecipientType.CC
		 * 和Message.RecipientType.BCC，TO表示主要接收人，CC表示抄送人，BCC表示秘密抄送人。接收者与发送者一样，通常使用InternetAddress的对象。
		 */
		me.setRecipient(MimeMessage.RecipientType.BCC, new InternetAddress(receiveMail, "admin", "UTF-8"));
		//设置标题
		me.setSubject("邮件来啦", "UTF-8");
		//设置正文
		me.setContent("对方基本信息是"+message,"text/html;charset=UTF-8");
		//设置发送时间
		me.setSentDate(new Date());
		//保存设置
		me.saveChanges();
		
		return me;
	} 
}