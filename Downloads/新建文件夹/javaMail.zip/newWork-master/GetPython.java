package JMailForPython;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class GetPython {

	public static String GetPythonMsg() {
		String str =GetPython.class.getClassLoader().getResource("JMailForPython/GetIp.py").getPath().substring(1);
		String[] arguments = new String[] {"python",str};
		String line = null;
		try {
			Process process = Runtime.getRuntime().exec(arguments);
			BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(),"gbk"));
			while((line = in.readLine())!=null) {
				System.out.println(line);
				return line;
			}
			in.close();
			process.waitFor();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

//	public static void main(String[] args) {
//		String str =GetPython.class.getClassLoader().getResource("JMailForPython/GetIp.py").getPath().substring(1);
//		System.out.println(str);
//	}
}
