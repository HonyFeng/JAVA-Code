package JMailForPython;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * 解密
 * @author gjt
 *
 */
public class DecodeByBase64 {
	public static Map<String, String> Decoding() {
		Map<String,String> map = EncodeByBase64.Encoding();
		Map<String,String> user = new HashMap<String,String>();
		Base64.Decoder decoder = Base64.getDecoder();
		try {
			user.put("QQ_num", new String(decoder.decode(map.get("QQ_num")), "UTF-8"));
			user.put("QQ_mm", new String(decoder.decode(map.get("QQ_pwd")), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return user;
	}
}

