package JMailForPython;

/**
 * 程序启动
 * @author gjt
 *
 */
public class GetIpForEmail {
	public static void main(String[] args) {
		try {
			QQEmail.getEmailContent();
		} catch (Exception e) {
			System.out.println("发送失败");
			e.printStackTrace();
		}
	}
}
