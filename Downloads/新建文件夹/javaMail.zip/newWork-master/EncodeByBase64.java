package JMailForPython;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * �˺ż���
 * @author gjt
 *
 */
public class EncodeByBase64 {
	final private static String QQ_num = "xxxx@qq.com";
	final private static String QQ_pwd = "独立密码";
	
	public static Map<String,String> Encoding() {
		Map<String,String> qq = new HashMap<>();
		Base64.Encoder encoder = Base64.getEncoder();
		byte[] textByte;
		try {
			textByte = QQ_num.getBytes("UTF-8");
			String QQ_numBase64 = encoder.encodeToString(textByte);
			textByte = QQ_pwd.getBytes("UTF-8");
			String QQ_pwdBase64 = encoder.encodeToString(textByte);
			qq.put("QQ_num", QQ_numBase64);
			qq.put("QQ_pwd", QQ_pwdBase64);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return qq;
	}
}
