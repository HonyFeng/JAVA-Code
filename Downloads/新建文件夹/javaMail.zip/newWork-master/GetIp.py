import requests
from bs4 import BeautifulSoup
def get_Out_Ip():
    url = "http://2017.ip138.com/ic.asp"
    txt = requests.get(url)
    soup = BeautifulSoup(txt.content.decode("gbk"),"html.parser")
    center = soup.find_all(["center"])
    return str(center[0]).split("[")[1].split("]")[0]
def get_address():
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3298.4 Safari/537.36"}
    url = "https://www.ipip.net/ip.html"
    txt = requests.get(url,headers = headers)
    soup = BeautifulSoup(txt.content.decode("utf-8"),"html.parser")
    center = soup.find_all("div", "panel-body")
    return str(center[1]).split(">")[2].split("<")[0]
print(get_Out_Ip()+"  "+get_address())
